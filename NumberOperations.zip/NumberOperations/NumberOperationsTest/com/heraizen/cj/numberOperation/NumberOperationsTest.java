package com.heraizen.cj.numberOperation;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class NumberOperationsTest {

	NumberOperation obj = new NumberOperation();

	@Test
	public void isPrimeTest() {
		assertEquals(true, obj.isPrime(5));
	}

	@Test
	public void isNotPrimeTest() {
		assertEquals(false, obj.isPrime(1));
	}

	@Test
	public void isPrimeNegativeTest() {
		assertEquals(false, obj.isPrime(-10));
	}

	@Test
	public void evenPrimeCheckTest() {
		assertEquals(true, obj.isPrime(2));
	}

	@Test
	public void evenNotPrimeCheckTest() {
		assertEquals(false, obj.isPrime(12));
	}

	// palindrome number

	@Test
	public void isPalindromeTest() {
		assertEquals(true, obj.isPalindrome(121));
	}

	@Test
	public void isNotPalindromeTest() {
		assertEquals(false, obj.isPalindrome(500));
	}

	@Test
	public void isNegPalindromeTest() {
		assertEquals(true, obj.isPalindrome(-525));
	}

	// palindrome string
	@Test
	public void isNotPalindromeStringTest() {
		assertEquals(false, obj.isPalindrome("Nishad"));
	}

	@Test
	public void isPalindromeStringTest() {
		assertEquals(true, obj.isPalindrome("Malayalam"));
	}

	// reverse
	@Test
	public void isNotReverseTest() {
		assertEquals(753, obj.isReverse(357));
	}

	@Test
	public void isReverseTest() {
		assertEquals(333, obj.isReverse(333));
	}

	@Test
	public void isNegReverseTest() {
		assertEquals(323, obj.isReverse(-323));
	}

	// Accept arr & key type integer as param and return sum of key.
	// @Test
	/*
	 * public void isKeySumOfArray() { int[] arrVal = {1,2,3,1}; assertEquals(4,
	 * obj.isArraySumEqualToKey(4, arrVal)); }
	 */

	// factorial
	@Test
	public void isFactorialTest() {
		assertEquals(5040, obj.Factorial(7));
	}

	@Test
	public void isFactorialNegTest() {
		assertEquals(0, obj.Factorial(-1));
	}

	@Test
	public void isFactorialOneTest() {
		assertEquals(1, obj.Factorial(1));
	}

	@Test
	public void isFactorialZeroTest() {
		assertEquals(0, obj.Factorial(0));
	}

	// list of even numbers
	
	  @Test public void isEvenTest() { 
	  int arrNum[] = {2,4,6,8};
	  assertEquals(Arrays.toString(arrNum), Arrays.toString(obj.Even(8)));
	 }
	  
	  @Test
	  public void isoddTest() { 
		  int arrNum[] = {2,4,6};
		  assertEquals(Arrays.toString(arrNum), Arrays.toString(obj.Even(7)));
		 }
	  
	  @Test
	  public void isEvenOneTest() { 
		  int emptyArr[] = {};
		  assertEquals(Arrays.toString(emptyArr), Arrays.toString(obj.Even(1)));
		 }
	  @Test
	  public void isEvenZeroTest() { 
		  int emptyArr[] = {};
		  assertEquals(Arrays.toString(emptyArr), Arrays.toString(obj.Even(0)));
		 }
	 

	// Sum of Digits
	  @Test 
	  public void isSumOfDigitTest() { 
		  assertEquals(45,obj.sumOfDigits(123456789)); 
	}
	  @Test 
	  public void isSumOfDigitNegTest() { 
		  assertEquals(45,obj.sumOfDigits(-123456789)); 
	}
	  @Test 
	  public void isSumOfDigitOneTest() { 
		  assertEquals(1,obj.sumOfDigits(1)); 
	}
	  @Test 
	  public void isSumOfDigitZeroTest() { 
		  assertEquals(0,obj.sumOfDigits(0)); 
	}
	  
	  //prime number b/w 'a' & 'b'
	  @Test 
	  public void isPrimebtwTest() { 
		  int arrPrime[] = {2,3,5,7};
		  assertEquals(Arrays.toString(arrPrime), Arrays.toString(obj.primeNumBtw(1, 10)));
	}
	  
	  @Test 
	  public void isNoPrimebtwTest() { 
		  int arrPrime[] = {};
		  assertEquals(Arrays.toString(arrPrime), Arrays.toString(obj.primeNumBtw(0,1)));
	}
	  @Test 
	  public void invalidPrimebtwTest() { 
		  int arrPrime[] = {};
		  assertEquals(Arrays.toString(arrPrime), Arrays.toString(obj.primeNumBtw(10,1)));
	}
	  //generate single number
	  @Test 
	  public void generateSumTest() { 
		  assertEquals("9,5" ,obj.GenerateSingleNum("99999", "9")); 
	}
	  @Test 
	  public void generateNegSumTest() { 
		  assertEquals("9,1",obj.GenerateSingleNum("123456789", "9")); 
	}
	  @Test 
	  public void generateNullSumTest() { 
		  assertEquals("0,0",obj.GenerateSingleNum("-1239", "4")); 
	}
	  @Test 
	  public void generateZeroSumTest() { 
		  assertEquals("0",obj.GenerateSingleNum("0", "0")); 
	}
	  @Test 
	  public void generateOneSumTest() { 
		  assertEquals("1",obj.GenerateSingleNum("1", "1")); 
	}
	  
	  //sum of we elements in the array
	  @Test 
	  public void isSumEleTest() { 
		  int arr[] = {7,3,4,2,8,9};
		  int arrOut[] = {7,2};
		  assertEquals(Arrays.toString(arrOut), Arrays.toString(obj.SumOfTwoArrayElement(arr, 9)));
	}
	  
		//remove duplicates from the string...
	  @Test 
	  public void removeDupStringTest() { 
		  assertEquals("cljva",obj.removeDuplicateString("jcljava")); 
	  }
	  
	//the sum of first ‘N’ Fibonacci series
	  @Test 
	  public void fabonacciSumTest() { 	  
		  assertEquals(12,obj.Fabonacci(6)); 
	  }
	  
	  //the missing number
	  @Test 
	  public void isMissingTest() { 
		  int arr[] = {1,2,3,4,5,6,8,9,10};
		  assertEquals(7,obj.MissingNum(arr)); 
	  }
	  
	  //GCD of 3 num
	  @Test 
	  public void isGCDTest() { 	  
		  assertEquals(7, obj.GCD(35, 42, 63)); 
	  }
	  @Test 
	  public void isGCDOneTest() { 	  
		  assertEquals(1, obj.GCD(10, 7, 11)); 
	  }
	  
	  /*Write a program to find the sum of positive numbers and negative numbers in the given M x N
		matrix. */
	  @Test 
	  public void sumOfPosAndNegTest() { 
		  int arr[][] = { {1, -2, 3}, {2,5,-8}, {4,6,-4} };
		  int arrOut[] = {21, -14};
		  assertEquals(Arrays.toString(arrOut), Arrays.toString(obj.sumOfPosAndNeg(arr))); 
	  }
	  @Test 
	  public void sumOfPosTest() { 
		  int arr[][] = { {1, 2, 3}, {2,5,4}, {4,6,1} };
		  int arrOut[] = {28, 0};
		  assertEquals(Arrays.toString(arrOut), Arrays.toString(obj.sumOfPosAndNeg(arr))); 
	  }
	  @Test 
	  public void sumOfNegTest() { 
		  int arr[][] = { {-1, -2, -3}, {-2,-5,-4}, {-4,-6,-1} };
		  int arrOut[] = {0, -28};
		  assertEquals(Arrays.toString(arrOut), Arrays.toString(obj.sumOfPosAndNeg(arr))); 
	  }
	  
	//generate prime number
	  @Test
	  public void isGeneratedPrimeTest() {
		  int[] arrOut = {2, 3, 5, 7, 11};
		  assertEquals(Arrays.toString(arrOut), Arrays.toString(obj.genPrime(5)));  
	  }
	  
		//count the number of prime numbers in the string
	  @Test
	  public void isCountPrimeTest() {
		  assertEquals(3, obj.countPrime(23897));  
	  }
	  @Test
	  public void isNoCountPrimeTest() {
		  assertEquals(0, obj.countPrime(19846));  
	  }
	  
	 // count the number of words in the given string
	  @Test
	  public void coountWordTest() {
		  assertEquals(6, obj.CountStringWord("core java java core advanced java"));  
	  }
}


