package com.heraizen.cj.numberOperation;

import java.util.Arrays;
import java.util.Scanner;

public class NumberOperation {

	//prime number
	public boolean isPrime(int num) {

		if (num <= 1)
			return false;

		if (num != 2 && num % 2 == 0)
			return false;

		for (int i = 2; i <= ((int) Math.sqrt(num)); i++) {
			if (num % i == 0)
				return false;
		}

		return true;
	}

	//palindrome number
	public boolean isPalindrome(int negNum) {

		int num = (int)Math.abs(negNum);
		int temp = num;
		int rev = 0;

		while (num > 0) {
		int	pal = num % 10;
			rev = (rev * 10) + pal;
			num = num / 10;
		}

		if (rev == temp)
			return true;

		return false;
	}

	//palindrome string
	public boolean isPalindrome(String str) {

		String pal = "";
		String strLower = str.toLowerCase();
		String temp = strLower;

		for (int i = strLower.length() - 1; i >= 0; i--) {
			pal = pal + strLower.charAt(i);
		}
		if (pal.equals(temp))
			return true;

		return false;
	}

	//reverse
	public int isReverse(int num) {
		int rev = 0;
		int numNeg = ((int)Math.abs(num));
		
		while (numNeg > 0) {
			int pal = numNeg % 10;
			rev = (rev * 10) + pal;
			numNeg = numNeg / 10;
		}

		return rev;
	}
	
	//Factorial
	public int Factorial(int num) {
		if(num <= 0)
		return 0;
		
		int fact =1;
		for(int i=1; i <= num; i++) {
			fact = fact * i;
		}
		return fact;
	}

	//List of N even numbers
	
	 public int[] Even(int num) {
		 int j = 0;
		 int[] emptyArr = {};
		 int size = num/2;
		 int[] arrNum = new int[size];
		 
		
		  if(num == 1 || num == 0)
		  { return emptyArr;
		  }
		 
		 for(int i=1; i<=num; i++) {
			 if(i%2 == 0) {
				 arrNum[j] = i;		
				 j++;
			 }
		 }
		 return arrNum;
		 }
	 
	
	//sum of digits
	public int sumOfDigits(int numNeg) {
		if(numNeg == 0)
		return 0;
		 
		if(numNeg == 1)
			return 1;
		
		int num = (int)Math.abs(numNeg);
		int sum = 0;
		while(num > 0) {
			int digit = num%10;
			sum = sum + digit;
			num = num/10;
		}
		return sum;
	}
	
	/*Write a program to accept the lower bound and upper bound values
	from the user and print the prime numbers between lower and upper bound.*/
	
	public int[]  primeNumBtw(int a, int b) {
		int arr[] = new int[range(a,b)];
		int j = 0;
		if(a < b) {
			for(int i=a; i<=b; i++) {
				if(isPrimeNum(i)) {
					arr[j++]=i;
				}
			}
			return arr;
		}
		else {
			return new int[] {};
		}
	}
	public boolean isPrimeNum(int num) {
		if(num<=1) {
			return false;
		}
		if(num!=2 && num%2==0) {
			return false;
		}
		for(int i = 2; i<=((int)(Math.sqrt(num))); i++) {
			if(num%i == 0) {
				return false;
			}
		}
		return true;
	}
	public int range(int a, int b) {
		int count =0;
		for(int i=a; i<=b; i++) {
			if(isPrimeNum(i)) {
				count++;
			}
		}
		return count;
	}
	
	//generate Single number
	public String GenerateSingleNum(String negNum, String key) {
		
		int strNum = 0, innersum = 0;
		int resSum = 0;
		int count = 0;
		int strKey = 0;
		
		if(negNum.equals("0"))
			return "0";
		
		if(negNum.equals("1"))
			return "1";
		
		if(negNum != "") {
			if(negNum.contains(key)) {
				strNum = Integer.parseInt(negNum);
				strKey = Integer.parseInt(key);
				
				while(strNum > 0) {
					int digit = strNum%10;
					if(digit == strKey) {
						count++;
						}
					innersum = innersum + digit;
					strNum = strNum/10;
				}
								
				while(innersum > 0) {
					int digit1 = innersum%10;
					resSum = resSum + digit1;
					innersum = innersum/10;
				}
			}
		}
		return resSum +","+ count;
	}	
	
	/*Write a method to accept an array and key of type integer as parameters and find two elements
in the array such that their sum is equal to given key.*/
	
	public int[] SumOfTwoArrayElement(int[] arr, int key) {
		int sum = 0;
		int[] res = new int[2];
		for(int i = 0; i < arr.length; i++) {
			for(int j = i+1; j<arr.length; j++) {
				sum = arr[i] + arr[j];
				if(sum == key) {
					res[0] = arr[i];
					res[1] = arr[j];
				}
			}
		}
		return res;
	}
	
	//remove duplicates from the string...
	
	public String removeDuplicateString(String str) {
		String res = "";
		outer:for(int i = 0; i < str.length(); i++) {
			for(int j = i+1; j < str.length(); j++) {
				if(i!=j && str.charAt(i) == str.charAt(j)) {
					continue outer;
				}
			}
			res = res + str.charAt(i);
		}
		return res;
	}
	
	//the sum of first ‘N’ Fibonacci series
	
	public int Fabonacci(int num) {
		int a = 0, b = 1;
		int res =0;
		int sum = 0;
		while(b <= num){
			sum = a + b;
			res = res + b;
			a = b;
			b = sum;
		}
		return res;
	}
	
	//missing number
	
	public int MissingNum(int[] arr) {
		int n = arr.length + 1;
		int sum = 0;
		
		int sumOf = n*(n+1)/2;
				
		for(int i=0; i<arr.length; i++) {
			sum = sum + arr[i];
		}	
		int res = sumOf - sum ;		
		return res;		
	}
	
	//GCD
	
	public int GCD(int a, int b, int c) {
		int gcd = 1;
		for(int i = 1; i<=a && i<=b && i<=c; i++) {
			if(a%i == 0 && b%i == 0 && c%i == 0 )
				gcd =i;
		}
		return gcd;
	}
	
	/*Write a program to find the sum of positive numbers and negative numbers in the given M x N
	matrix. */
	
	public int[] sumOfPosAndNeg(int arr[][]) {
		int output[] = new int[2];
		int pos = 0, neg = 0;
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				if(arr[i][j] > 0) {
					pos = pos + arr[i][j];
				}
				else {
					neg = neg + arr[i][j];
				}
			}
		}
		output[0] = pos;
		output[1] = neg;
		return output;
	}
	
	//generate prime number
	
	public int[] genPrime(int num) {
		int arr[] = new int[num];
		int k = 0;
		int prime = 2;
		while(num > 0) {
			if(isPrime(prime)) {
				arr[k++] = prime;
				num--;
			}
			prime++;
		}
		return arr;
	}
	
	//count the number of prime numbers in the string
	
	public int countPrime(int num){
		int count = 0, digit;
			while(num > 0) {
				digit = num % 10;
				if(isPrime(digit))
					count++;
				num /= 10;
			}
		return count;
	}

//count the number of words in the given string

	public int CountStringWord(String str) {
		String[] arr = str.split(" ");
		return arr.length;
	}
}


